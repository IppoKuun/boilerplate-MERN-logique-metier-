import {Router} from "express"
import requireAuth from "../middlewares/requireAuth";
import * as productControllers from "../controllers/productControllers"
import validate from "../middlewares/validate";
import productValidator from "../middlewares/product.validator";

const { productQuery, productBase, updateVehicleBody, idParam } = productValidator

export const productRouter = Router()

productRouter.get("/", validate({query : productQuery}), productControllers.list)

productRouter.get("/:id", validate({params : idParam}), productControllers.getProduct)

productRouter.get("/slug/:slug", productControllers.getProductBySlug);

productRouter.post("/", validate({body: productBase}), requireAuth(["owner", "admin"]),  productControllers.postProduct)

productRouter.patch("/:id", validate({ body: updateVehicleBody }) ,requireAuth(["owner", "admin"]) ,productControllers.updateProduct )

productRouter.delete("/:id", validate({params: idParam }), requireAuth(["owner", "admin"]),  productControllers.deleteProduct)

productRouter.get("/count", async (req, res) => {
  try {
    const count = await Product.estimatedDocumentCount();
    res.json({ count });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Unable to count products" });
  }
});


