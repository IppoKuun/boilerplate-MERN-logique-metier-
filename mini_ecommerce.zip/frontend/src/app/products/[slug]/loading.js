// frontend/src/app/products/[slug]/loading.js
export default function Loading() {
  return (
    <div className="p-6 text-center text-slate-500">
      Chargement du produit...
    </div>
  );
}
